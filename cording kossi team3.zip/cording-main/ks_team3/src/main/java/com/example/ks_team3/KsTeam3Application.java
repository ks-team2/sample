package com.example.ks_team3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KsTeam3Application {

	public static void main(String[] args) {
		SpringApplication.run(KsTeam3Application.class, args);
	}

}
