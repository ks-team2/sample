package com.example.ks_team3.controller;

import java.text.SimpleDateFormat;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.management.loading.PrivateClassLoader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.ks_team3.dto.ApplyReason;
import com.example.ks_team3.dto.ApplyStatus;
import com.example.ks_team3.dto.Department;
import com.example.ks_team3.repository.ApplyReasonRepository;
import com.example.ks_team3.repository.ApplyStatusRepository;
import com.example.ks_team3.repository.DepartmentRepository;
import com.example.ks_team3.repository.UsersRepository;
import com.fasterxml.jackson.databind.deser.impl.CreatorCandidate.Param;

import ch.qos.logback.core.joran.spi.ElementSelector;

import com.example.ks_team3.dto.Attendance;
import com.example.ks_team3.dto.Company;
import com.example.ks_team3.dto.Users;
import com.example.ks_team3.param.AdministerParam;
import com.example.ks_team3.param.AttendanceParam;
import com.example.ks_team3.repository.AttendanceRepository;
import com.example.ks_team3.repository.AttendanceService;
////Specificationsでの実装を検討
//import com.example.ks0619.repository.AttendanceSpecifications;
import com.example.ks_team3.repository.CompanyRepository;


@ComponentScan
@Controller
public class AdministerController {
	
	@Autowired
	private UsersRepository usersRepository;	
	@Autowired
	private AttendanceRepository attendanceRepository;	
	@Autowired
	public AttendanceService attendanceService;	
	@Autowired
	private DepartmentRepository departmentRepository;	
	@Autowired
	private ApplyReasonRepository applyReasonRepository;	
	@Autowired
	private ApplyStatusRepository applyStatusRepository;	
	@Autowired
	private CompanyRepository companyRepository;	
	
	
	boolean successMessage = false;
	boolean errorMessage = false;
	String updateMessage = "";
	
	boolean nowYearMonth = true;
	String yearMonth = "";
	
	//検討　カラーリング機能
	String[] checked = {""};
	
	
	
	@GetMapping(path = "/administer")
	public String list(Model model) {
		
		//権限者がこの画面に遷移するように
		//ログイン画面から受け取る
		
		List<Attendance> attendances = attendanceService.find("","","","","");
		model.addAttribute("attendances", attendances);
		model.addAttribute("main", "administer-find::main");
		
		//マスタ参照によるコンボックス選択名称の取得は、メソッドとかクラスとかでまとめられるかも
		//所属名称の取得 do　削除フラグでもソート
		List<Department> departments = departmentRepository.getDepartment();
		model.addAttribute("departments", departments);
				
		//申請事由名称の取得
		List<ApplyReason> applyReasons= applyReasonRepository.getApplyReason();
		model.addAttribute("applyReasons", applyReasons);
						
		//申請状態名称の取得
		List<ApplyStatus> applyStatus = applyStatusRepository.getApplyStatus();
		model.addAttribute("applyStatus", applyStatus);	
		
		return "administer-list";
				
	}

	

	@PostMapping("/search")
	public String serch (AdministerParam param,Model model) {
		
		List<Attendance> attendances = attendanceService.find
				(param.getUserId(),param.getUserName()
				,param.getDepartmentId(),param.getApplyReasonId(),param.getApplyStatusId());
		model.addAttribute("attendances", attendances);
		model.addAttribute("main", "administer-find::main");
		
		
		//マスタ参照によるコンボックス選択名称の取得は、メソッドとかクラスとかでまとめたい、、、
		//所属名称の取得 do　削除フラグでもソート
		List<Department> departments = departmentRepository.getDepartment();
		model.addAttribute("departments", departments);
				
		//申請事由名称の取得
		List<ApplyReason> applyReasons= applyReasonRepository.getApplyReason();
		model.addAttribute("applyReasons", applyReasons);
						
		//申請状態名称の取得
		List<ApplyStatus> applyStatus = applyStatusRepository.getApplyStatus();
		model.addAttribute("applyStatus", applyStatus);	
		
		return "administer-list";
	}
	
	
	
	////修正画面	////
	
	
	@PostMapping("/chosenUser")
	public String chosenUser(AdministerParam param,Model model) {
		
		//社員情報
		List<Users> users = usersRepository.onesUsers
				(param.getChosenUser());
		model.addAttribute("users", users);
		//会社情報
		List<Company> company = companyRepository.getCompany();
		model.addAttribute("company", company);					
		
		//現在の年月を取得
		
		yearMonth = "%"+param.getChosenYearMonth()+"%";
		
		
		if (yearMonth.equals("%null%")) {
			
			Calendar calendar = Calendar.getInstance();
			String yyyy = String.valueOf(calendar.get(Calendar.YEAR));
			String mm = "";
			
			int month = calendar.get(Calendar.MONTH) + 1;
			
			if (month<10) {
				
				mm = "0"+String.valueOf(month);
				
			}else {
				mm = String.valueOf(month);
			}
			
	        yearMonth = "%"+yyyy+"-"+mm+"%"; 
	        	        
		} 
		
		model.addAttribute("yearMonth", yearMonth);
		

		
		//勤怠実績の表示
		List<Attendance> attendances = attendanceRepository.onesAttendance
				(param.getChosenUser(),yearMonth);
//		List<Attendance> workingHoursTotal = attendanceRepository.workingHoursTotal
//				(param.getChosenUser(),yearMonth);
//		List<Attendance> overtimeHoursTotal = attendanceRepository.overtimeHoursTotal
//				(param.getChosenUser(),yearMonth);
		
		List<Attendance>totalHours = attendanceService.TotalHours(param.getChosenUser(), yearMonth);
						
		model.addAttribute("attendances", attendances);
//		model.addAttribute("workingHoursTotal", workingHoursTotal);
//		model.addAttribute("overtimeHoursTotal", overtimeHoursTotal);
		model.addAttribute("totalHours", totalHours);
		
		//曜日の取得		
						
		//申請事由名称の取得
		List<ApplyReason> applyReasons= applyReasonRepository.getApplyReason();
		model.addAttribute("applyReasons", applyReasons);
						
		//申請状態名称の取得
		List<ApplyStatus> applyStatus = applyStatusRepository.getApplyStatus();
		model.addAttribute("applyStatus", applyStatus);
		
		model.addAttribute("chosenUser", param.getChosenUser());
		
				
		if (successMessage) {
			updateMessage="更新が完了しました。";
			successMessage = false;
		}
		else if (errorMessage) {
			updateMessage="！！！更新できませんでした。更新したい行を選択チェックしてください。！！！";
			errorMessage = false;
		} else {
			updateMessage="";
		}
		     
		//表示させたいメッセージを渡す
		model.addAttribute("updateMessage", updateMessage);
		
		//検討　変更箇所のカラーリング
		model.addAttribute("checked", checked);		
		
		return "administer-fix";
						
	}
			
	
	//更新
	
	@PostMapping("/update")
	public String update(AttendanceParam param,Model model) {
		 			
		try {
			
			for (int i = 0; i < param.getCheck().length; i++) {
				
				
				if (!"".equals(param.getCheck()[i])) {
					
					//文字列から時間を切り出し
					String shh = param.getStartTime()[i].substring(0,2);
					String smm = param.getStartTime()[i].substring(3,5);
					String rhh = param.getRestHours()[i].substring(0,2);
					String rmm = param.getRestHours()[i].substring(3,5);
					String ehh = param.getEndTime()[i].substring(0,2);
					String emm = param.getEndTime()[i].substring(3,5);
					
					//intに変換
					int shhInt = Integer.parseInt(shh);
					int smmInt = Integer.parseInt(smm);
					int rhhInt = Integer.parseInt(rhh);
					int rmmInt = Integer.parseInt(rmm);					
					int ehhInt = Integer.parseInt(ehh);
					int emmInt = Integer.parseInt(emm);
					
					//時間→分
					int startTimeMinutes = shhInt*60 + smmInt;
					int RestHoursMinutes = rhhInt*60 + smmInt;
					int endTimeMinutes = ehhInt*60 + emmInt;
					

					int getWorkingMinutes = endTimeMinutes - startTimeMinutes - RestHoursMinutes;
					double getWorkingHours = (double)getWorkingMinutes/60;
					
					//model.addAttribute("test", getWorkingHours);
					
					//1日に8時間を規定作業時間とし、超過分を残業時間として算出
					double getovertimeHours = getWorkingHours-(double)8;										
		
					attendanceRepository.updateAttendance
					(param.getChosenUser()
					,param.getCheck()[i]
					,param.getStartTime()[i]
					,param.getRestHours()[i]
					,param.getEndTime()[i]
					,getWorkingHours
					,getovertimeHours
					,param.getRemarks()[i]
					,param.getApplyReasonId()[i]
					,param.getApplyStatusId()[i]
					,param.getUpdateUser()[i]
					,param.getUpdateComment()[i]);
													
				}
					
			}
			
			
			successMessage = true;
			//return "test";
			
			return "forward:chosenUser";
			
		} catch (NullPointerException e) {
			
			errorMessage = true;
			return "forward:chosenUser";
			
		}
				
		
	}

	


	
	
	
	
	
	
	
	
	
	
	

	
	
}
