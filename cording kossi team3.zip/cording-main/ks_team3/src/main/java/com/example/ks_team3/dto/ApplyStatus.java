package com.example.ks_team3.dto;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;

@Data
@Entity(name = "m_apply_status")
public class ApplyStatus {
	
	@Id
	private String APPLY_STATUS_ID;
	private String APPLY_STATUS_NAME;
	private int DEL_FLG;								
	private Date CREATE_DATE;								
	private String CREATE_USER;								
	private Date UPDATE_DATE;								
	private String UPDATE_USER;
	
	@OneToMany
	(mappedBy = "applyStatus",cascade = CascadeType.ALL)
	private List<Attendance> attendances;

}
