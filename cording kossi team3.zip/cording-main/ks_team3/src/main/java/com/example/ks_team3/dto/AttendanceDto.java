//package com.example.ks_team3.dto;
//
//import java.util.Date;
//
//import lombok.Data;
//
//@Data
//public class AttendanceDto {
//	
//	private double w;
//			
//
//}
