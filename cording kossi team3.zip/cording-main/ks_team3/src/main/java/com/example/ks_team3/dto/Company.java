package com.example.ks_team3.dto;

import java.util.Date;


import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity(name = "m_company")
public class Company {
	
	@Id
	private String COMPANY_ID;
	private String COMPANY_ADDRESS;
	private String COMPANY_NAME;
	private int DEL_FLG;						
	private Date CREATE_DATE;								
	private String CREATE_USER;					
	private Date UPDATE_DATE;								
	private String UPDATE_USER;
	

}
