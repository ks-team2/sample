package com.example.ks_team3.dto;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;

@Data
@Entity(name = "m_department")
public class Department {
	
	@Id
	private String DEPARTMENT_ID;	
	private String DEPARTMENT_NAME;	
	private int DEL_FLG;								
	private Date CREATE_DATE;								
	private String CREATE_USER;								
	private Date UPDATE_DATE;								
	private String UPDATE_USER;
	
	@OneToMany
	(mappedBy = "department",cascade = CascadeType.ALL)
	private List<Users> users;

}
