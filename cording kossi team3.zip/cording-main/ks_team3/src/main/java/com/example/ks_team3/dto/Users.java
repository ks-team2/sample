package com.example.ks_team3.dto;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.Data;

@Data
@Entity(name = "t_users")
public class Users {
	
	@Id
	private String USER_ID;
	
	private int ADMINISTER_ID;
	
	
	private String PASSWORD;							
	private int USER_NYUUSHAJIKAN;							
	private String USER_NAME;								
	private String USER_SEIBETU;								
	private int USER_NENREI;
	
	@ManyToOne
	@JoinColumn(name = "DEPARTMENT_ID")
	private Department department ;
	
	private String USER_EMAIL;
	
	private int DEL_FLG;						
	private Date CREATE_DATE;								
	private String CREATE_USER;					
	private Date UPDATE_DATE;								
	private String UPDATE_USER;
	
	@OneToMany
	(mappedBy = "user",cascade = CascadeType.ALL)
	private List<Attendance> attendances;
	
	

}
