package com.example.ks_team3.param;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.example.ks_team3.dto.Attendance;

import lombok.Data;

@Data
public class AdministerParam {
	
	//一覧画面
	private String userId;	
	private String userName;	

	private String departmentId;	
	private String applyReasonId;	
	private String applyStatusId;
		
	//可能であれば実装　入社年月日、勤怠年月日
//	private int startN;	
//	private int startK;	
		
	private String chosenUser;
	
	private String chosenYearMonth;


}
