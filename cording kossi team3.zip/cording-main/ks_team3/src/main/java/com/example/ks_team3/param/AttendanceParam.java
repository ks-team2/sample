package com.example.ks_team3.param;


import java.util.Date;
import java.util.List;

import lombok.Data;


@Data
public class AttendanceParam {
	
	private String chosenUser;
	
//修正画面
	private String[] check;	
	private String[] startTime;
	private String[] restHours;
	private String[] endTime;	
	private double[] workingHours;
	private double[] overtimeHours;
	private String[] remarks;
	private String[] applyReasonId;
	private String[] applyStatusId;
	private String[] updateUser;	
	private String[] updateComment;
	


}
