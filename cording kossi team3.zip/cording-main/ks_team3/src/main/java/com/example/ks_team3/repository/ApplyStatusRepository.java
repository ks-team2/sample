package com.example.ks_team3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.ks_team3.dto.ApplyReason;
import com.example.ks_team3.dto.ApplyStatus;
import com.example.ks_team3.dto.Attendance;
import com.example.ks_team3.dto.Department;
import com.example.ks_team3.dto.Users;

import ch.qos.logback.core.joran.conditional.IfAction;



@Repository
public interface ApplyStatusRepository 
	extends JpaRepository<ApplyStatus, Integer>{	


	@Query 
	(value  = "SELECT *"
			+ " FROM m_apply_status"
			+ " WHERE del_flg = 0",nativeQuery = true)
	List<ApplyStatus>getApplyStatus();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//Attendanceテーブルが中心なので、クラスを変更
	
//	@Query 
//	(value  = "SELECT"
//			+ " t_users.user_id,t_users.user_name"
//			+ ",m_department.department_name"
//			+ ",m_apply_reason.apply_reason_name"
//			+ ",m_apply_status.apply_status_name"
//			+ " FROM t_users"
//			+ " INNER JOIN t_attendance ON t_users.user_id = t_attendance.user_id"
//			+ " LEFT JOIN m_department ON t_users.department_id = m_department.department_id"
//			+ " LEFT JOIN m_apply_reason ON t_attendance.apply_reason_id = m_apply_reason.apply_reason_id"
//			+ " LEFT JOIN m_apply_status ON t_attendance.apply_status_id = m_apply_status.apply_status_id"
//			+ " where t_users.user_id = :USER_ID"
//			+ " AND t_users.user_name = :USER_NAME"
//			+ " AND m_department.department_id = :DEPARTMENT_ID"
//			+ " AND m_apply_reason.apply_reason_id = :APPLY_REASON_ID"
//			+ " AND m_apply_status.apply_status_id = :APPLY_STATUS_ID",nativeQuery = true)
	
	//？　上記のクエリ分だと、not　found　colum　のエラーが出る。
	//　下記のクエリ文では一応通るも、find.htmlでのuserリストの出力がうまくいかない。
	
	
	
////静的クエリ文の実装	
	
//	@Query 
//	(value  = "SELECT *"
//			+ " FROM t_attendance"
//			+ " INNER JOIN t_users ON t_users.user_id = t_attendance.user_id"
//			+ " LEFT JOIN m_department ON t_users.department_id = m_department.department_id"
//			+ " LEFT JOIN m_apply_reason ON t_attendance.apply_reason_id = m_apply_reason.apply_reason_id"
//			+ " LEFT JOIN m_apply_status ON t_attendance.apply_status_id = m_apply_status.apply_status_id"
//			+ " GROUP BY t_users.user_id",nativeQuery = true)
//	List<Attendance> findAll();
//	
//	
//	//分割してテーブルを抽出
//
//	@Query
//	(value = "SELECT *"
//			+ " FROM t_attendance"
//			+ " INNER JOIN t_users ON t_users.user_id = t_attendance.user_id"
//			+ " LEFT JOIN m_apply_reason ON t_attendance.apply_reason_id = m_apply_reason.apply_reason_id"
//			+ " LEFT JOIN m_apply_status ON t_attendance.apply_status_id = m_apply_status.apply_status_id"
//			+ " where m_apply_reason.apply_reason_id = :APPLY_REASON_ID"
//			+ " AND m_apply_status.apply_status_id = :APPLY_STATUS_ID"
//			+ " GROUP BY t_users.user_id",nativeQuery = true)		
//	List<Attendance> findByAttendance
//	(@Param ("APPLY_REASON_ID") String applyReasonId ,@Param ("APPLY_STATUS_ID") String applyStatusId
//			);
//	
//	//全条件が入力された場合の静的クエリ文
//	@Query 
//	(value  = "SELECT *"
//			+ " FROM t_attendance"
//			+ " INNER JOIN t_users ON t_users.user_id = t_attendance.user_id"
//			+ " LEFT JOIN m_department ON t_users.department_id = m_department.department_id"
//			+ " LEFT JOIN m_apply_reason ON t_attendance.apply_reason_id = m_apply_reason.apply_reason_id"
//			+ " LEFT JOIN m_apply_status ON t_attendance.apply_status_id = m_apply_status.apply_status_id"
//			+ " where t_users.user_id = :USER_ID"
//			+ " AND t_users.user_name = :USER_NAME"
//			+ " AND m_department.department_id = :DEPARTMENT_ID"
//			+ " AND m_apply_reason.apply_reason_id = :APPLY_REASON_ID"
//			+ " AND m_apply_status.apply_status_id = :APPLY_STATUS_ID"
//			+ " GROUP BY t_users.user_id",nativeQuery = true)
//	List<Attendance> findByBoth
//	(@Param ("USER_ID") String userId,@Param ("USER_NAME") String userName,@Param ("DEPARTMENT_ID") String departmentId
//			,@Param ("APPLY_REASON_ID") String applyReasonId ,@Param ("APPLY_STATUS_ID") String applyStatusId);
//	
//	
//	
	

	
	
	









}
