package com.example.ks_team3.repository;

import java.time.YearMonth;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.ks_team3.dto.Attendance;
import com.example.ks_team3.dto.Users;

import ch.qos.logback.core.joran.conditional.IfAction;


@Repository
public interface AttendanceRepository 
	extends JpaRepository<Attendance, Integer>{	


//	@Query 
//	(value  = "SELECT *"
//			+ " FROM t_attendance"
//			+ " INNER JOIN t_users ON t_users.user_id = t_attendance.user_id"
//			+ " LEFT JOIN m_department ON t_users.department_id = m_department.department_id"
//			+ " LEFT JOIN m_apply_reason ON t_attendance.apply_reason_id = m_apply_reason.apply_reason_id"
//			+ " LEFT JOIN m_apply_status ON t_attendance.apply_status_id = m_apply_status.apply_status_id"
//			+ " where t_users.user_id = :USER_ID"
//			+ " AND t_attendance.attendance_date LIKE :ATTENDANCE_DATE"
//			+ " AND t_attendance.del_flg = 0"
//			+ " ORDER BY t_attendance.attendance_date"			
//						,nativeQuery = true)
//	List<Attendance> onesAttendance
//	(@Param ("USER_ID") String chosenUser,@Param ("ATTENDANCE_DATE") String yearMonth);
	
	
	
	@Query 
	(value  = "SELECT *"
			+ " FROM t_attendance"
			+ " INNER JOIN t_users ON t_users.user_id = t_attendance.user_id"
			+ " LEFT JOIN m_department ON t_users.department_id = m_department.department_id"
			+ " LEFT JOIN m_apply_reason ON t_attendance.apply_reason_id = m_apply_reason.apply_reason_id"
			+ " LEFT JOIN m_apply_status ON t_attendance.apply_status_id = m_apply_status.apply_status_id"
			+ " where t_users.user_id = :USER_ID"
			+ " AND t_attendance.attendance_date LIKE :ATTENDANCE_DATE"
			+ " AND t_attendance.del_flg = 0"
			+ " ORDER BY t_attendance.attendance_date"			
						,nativeQuery = true)
	List<Attendance> onesAttendance
	(@Param ("USER_ID") String chosenUser,@Param ("ATTENDANCE_DATE") String yearMonth);
	
	
	//クエリ文をわける
	//sumのカラムをHTMLで取得できない、DTOでの宣言の仕方がわからなかったので、カスタムしたリポジトリーで実行を検討
//	@Query 
//	(value  = "SELECT attendance_id,sum(working_hours) as w"
//			+ " FROM t_attendance"
//			+ " where user_id = :USER_ID"
//			+ " AND attendance_date LIKE :ATTENDANCE_DATE"
//			+ " AND del_flg = 0"	
//			,nativeQuery = true)
//	List<Attendance> workingHoursTotal
//	(@Param ("USER_ID") String chosenUser,@Param ("ATTENDANCE_DATE") String yearMonth);
//	
//	@Query 
//	(value  = "SELECT attendance_id,sum(overtime_hours)"
//			+ " FROM t_attendance"
//			+ " where user_id = :USER_ID"
//			+ " AND attendance_date LIKE :ATTENDANCE_DATE"
//			+ " AND del_flg = 0"	
//			,nativeQuery = true)
//	List<Attendance> overtimeHoursTotal
//	(@Param ("USER_ID") String chosenUser,@Param ("ATTENDANCE_DATE") String yearMonth);
	
	
	
	
//	
//
//	
	
	//検討　時間項目の計算	
//	@Query 
//	(value  = "UPDATE t_attendance"
//			+ " SET start_time = :START_TIME"
//			+ ",end_time = :END_TIME"
//			+ ",remarks = :REMARKS"
//			+ ",apply_reason_id = :APPLY_REASON_ID"
//			+ ",apply_status_id = :APPLY_STATUS_ID"
//			+ ",update_user = :UPDATE_USER"
//			+ ",update_comment = :UPDATE_COMMENT"
//			+ " where user_id = :USER_ID"
//			+ " AND attendance_date = :ATTENDANCE_DATE"
//			+ " AND t_attendance.del_flg = 0"									
//			,nativeQuery = true)
//	@Modifying //（UPDATE、DELETE）のクエリ
//	@Transactional
//	void updateAttendance
//	(@Param ("USER_ID")String chosenUserId
//			,@Param ("ATTENDANCE_DATE")String check
//			,@Param ("START_TIME")String startTime
//			,@Param ("END_TIME")String endTime
//			,@Param ("REMARKS")String remarks
//			,@Param ("APPLY_REASON_ID")String applyReasonId
//			,@Param ("APPLY_STATUS_ID")String applyStatusId
//			,@Param ("UPDATE_USER")String updateUser
//			,@Param ("UPDATE_COMMENT")String updateComment);
	
		

	//検討　時間項目の計算	
	@Query 
	(value  = "UPDATE t_attendance"
			+ " SET start_time = :START_TIME"
			+ ",rest_hours = :REST_HOURS"
			+ ",end_time = :END_TIME"
			+ ",working_hours = :WORKING_HOURS"
			+ ",overtime_hours = :OVERTIME_HOURS"
			+ ",remarks = :REMARKS"
			+ ",apply_reason_id = :APPLY_REASON_ID"
			+ ",apply_status_id = :APPLY_STATUS_ID"
			+ ",update_user = :UPDATE_USER"
			+ ",update_comment = :UPDATE_COMMENT"
			+ " where user_id = :USER_ID"
			+ " AND attendance_date = :ATTENDANCE_DATE"
			+ " AND t_attendance.del_flg = 0"									
			,nativeQuery = true)
	@Modifying //（UPDATE、DELETE）のクエリ
	@Transactional
	void updateAttendance
	(@Param ("USER_ID")String chosenUserId
			,@Param ("ATTENDANCE_DATE")String check
			,@Param ("START_TIME")String startTime
			,@Param ("REST_HOURS")String restHours
			,@Param ("END_TIME")String endTime
			,@Param ("WORKING_HOURS")double getWorkingHours
			,@Param ("OVERTIME_HOURS")double getovertimeHours
			,@Param ("REMARKS")String remarks
			,@Param ("APPLY_REASON_ID")String applyReasonId
			,@Param ("APPLY_STATUS_ID")String applyStatusId
			,@Param ("UPDATE_USER")String updateUser
			,@Param ("UPDATE_COMMENT")String updateComment);
	

}
