package com.example.ks_team3.repository;

import java.util.List;

import com.example.ks_team3.dto.Attendance;
import com.example.ks_team3.param.AdministerParam;

public interface AttendanceRepositoryCustom {
	
	public List<Attendance> find(String userId,String userName,String departmentId,String applyReasonId,String applyStatusId);
	
	//独自のリポジトリーを作成するために、インタフェースを宣言

}
