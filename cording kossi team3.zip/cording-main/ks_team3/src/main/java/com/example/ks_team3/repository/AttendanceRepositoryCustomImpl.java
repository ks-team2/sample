package com.example.ks_team3.repository;

import java.util.List;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.ks_team3.dto.Attendance;
import com.example.ks_team3.param.AdministerParam;


@Component
//beanとして登録するためのアノテーション
public class AttendanceRepositoryCustomImpl implements AttendanceRepositoryCustom {
	
	//インタフェースの実装を行い、独自のリポジトリーを作成
	
	
	@Autowired
	EntityManager manager;
	
		
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Attendance> find(String userId,String userName,String departmentId,String applyReasonId,String applyStatusId) {
		
		StringBuilder sql = new StringBuilder();
		
		//初期表示、全条件が未入力の場合
		if ("".equals(userId) 
				&& "".equals(userName) 
				&& "".equals(departmentId) 
				&& "".equals(applyReasonId)
				&& "".equals(applyStatusId)) {
			
			sql.append("SELECT"
					+ " t_users.user_id,t_users.user_name"
					+ " ,m_department.department_name"
					+ " ,m_apply_reason.apply_reason_name"
					+ " ,m_apply_status.apply_status_name"
					+ " From t_attendance "
					+ " INNER JOIN t_users ON t_users.user_id = t_attendance.user_id"
					+ " LEFT JOIN m_department ON t_users.department_id = m_department.department_id"
					+ " LEFT JOIN m_apply_reason ON t_attendance.apply_reason_id = m_apply_reason.apply_reason_id"
					+ " LEFT JOIN m_apply_status ON t_attendance.apply_status_id = m_apply_status.apply_status_id"
					+ " WHERE t_users.del_flg = 0"
					+ " AND t_attendance.del_flg = 0"
					+ " GROUP BY t_users.user_id"
					+ " ORDER BY t_users.user_id");
			Query query = manager.createNativeQuery(sql.toString());
			
			return query.getResultList();
		
		//初期表示、全条件が未入力　以外の場合
		} else {
		    
			sql.append("SELECT"
					+ " t_users.user_id,t_users.user_name"
					+ " ,m_department.department_name"
					+ " ,m_apply_reason.apply_reason_name"
					+ " ,m_apply_status.apply_status_name"
					+ " From t_attendance "
					+ " INNER JOIN t_users ON t_users.user_id = t_attendance.user_id"
					+ " LEFT JOIN m_department ON t_users.department_id = m_department.department_id"
					+ " LEFT JOIN m_apply_reason ON t_attendance.apply_reason_id = m_apply_reason.apply_reason_id"
					+ " LEFT JOIN m_apply_status ON t_attendance.apply_status_id = m_apply_status.apply_status_id"
					+ " WHERE t_users.del_flg = 0"
					+ " AND t_attendance.del_flg = 0"
					+ " AND ");
			
			//スイッチ的な
			boolean andFlg = false;
			boolean userIdFlg = false;
			boolean userNameFlg = false;
			boolean departmentIdFlg = false;
			boolean applyReasonIdFlg = false;
			boolean applyStatusIdFlg = false;
			
			
			//条件に入力が合った場合に、sglが追加される
			
			if (!"".equals(userId)) {
				
				sql.append(" t_users.user_id = :USER_ID ");
				
				
				userIdFlg = true;
				andFlg = true;
				
			}
			

			if (!"".equals(userName)) {
				if (andFlg) sql.append(" AND ");
				sql.append(" t_users.user_name LIKE :USER_NAME ");
				
				
				userNameFlg = true;
				andFlg = true;
				
			}
			

			if (!"".equals(departmentId)) {
				if (andFlg) sql.append(" AND ");
				sql.append(" m_department.department_id = :DEPARTMENT_ID ");
				
				
				departmentIdFlg = true;
				andFlg = true;
				
			}
			

			if (!"".equals(applyReasonId)) {
				if (andFlg) sql.append(" AND ");
				sql.append(" m_apply_reason.apply_reason_id = :APPLY_REASON_ID ");
				
				
				applyReasonIdFlg = true;
				andFlg = true;
				
			}
			

			if (!"".equals(applyStatusId)) {
				if (andFlg) sql.append(" AND ");
				sql.append(" m_apply_status.apply_status_id = :APPLY_STATUS_ID ");
				
				
				applyStatusIdFlg = true;
				andFlg = true;
				
			}
			
			
			if (andFlg) {
				sql.append(" GROUP BY t_users.user_id ORDER BY t_users.user_id ");
			}
					
			
			//パラメーターを入れる
			Query query = manager.createNativeQuery(sql.toString());
			if (userIdFlg) query.setParameter("USER_ID", userId);
			if (userNameFlg) query.setParameter("USER_NAME", "%" + userName + "%");
			if (departmentIdFlg) query.setParameter("DEPARTMENT_ID", departmentId);
			if (applyReasonIdFlg) query.setParameter("APPLY_REASON_ID", applyReasonId);
			if (applyStatusIdFlg) query.setParameter("APPLY_STATUS_ID", applyStatusId);
			
			//結果をリストとして返す
			return query.getResultList();
		}
		
	
				
	}
	
	
	

}
