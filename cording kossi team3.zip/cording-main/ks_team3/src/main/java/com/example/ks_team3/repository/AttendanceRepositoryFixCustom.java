package com.example.ks_team3.repository;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.ks_team3.dto.Attendance;

@Component
public class AttendanceRepositoryFixCustom {
	
	@Autowired
	EntityManager manager;
	
	@SuppressWarnings("unchecked")
	public List<Attendance> TotalHours (String chosenUser,String yearMonth){
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT attendance_id,sum(working_hours),sum(overtime_hours)"
				+ " FROM t_attendance"
				+ " where user_id = :USER_ID"
				+ " AND attendance_date LIKE :ATTENDANCE_DATE"
				+ " AND del_flg = 0");
			
		Query query = manager.createNativeQuery(sql.toString());
		query.setParameter("USER_ID", chosenUser);
		query.setParameter("ATTENDANCE_DATE", yearMonth);
		
		return query.getResultList();	
		
	}
	
	
		
		
		
	
	
	
		
		
		
	
		
		
	

}
