package com.example.ks_team3.repository;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.example.ks_team3.dto.Attendance;
import com.example.ks_team3.param.AdministerParam;

@Service
public class AttendanceService {
	
	//検討　サービスはつくらずに、直接コントローラーで呼び出してもいいのかもしれない

	@Autowired
	AttendanceRepository attendanceRepository;
	
	@Autowired
	AttendanceRepositoryCustom attendanceRepositoryCustom;
	
	@Autowired
	AttendanceRepositoryFixCustom attendanceRepositoryFixCustom;
	
	
	public List<Attendance> find(String userId,String userName,String departmentId,String applyReasonId,String applyStatusId) {
		
		List<Attendance> attendances;	
			attendances = attendanceRepositoryCustom.find(userId,userName,departmentId,applyReasonId,applyStatusId);
		
		return attendances;
		
	}
	
	public List<Attendance> TotalHours(String chosenUser,String yearMonth){
		
		List<Attendance> TotalHours;
		TotalHours = attendanceRepositoryFixCustom.TotalHours(chosenUser, yearMonth);
		
		return TotalHours;
	}
	
	



}
