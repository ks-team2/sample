package com.example.ks_team3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.ks_team3.dto.Attendance;
import com.example.ks_team3.dto.Users;

public interface UsersRepository extends CrudRepository<Users, Integer>{

	@Query 
	(value  = "SELECT *"
			+ " FROM t_users"
			+ " LEFT JOIN m_department ON t_users.department_id = m_department.department_id"
			+ " where t_users.user_id = :USER_ID"
			+ " AND t_users.del_flg = 0"
			,nativeQuery = true)
	List<Users> onesUsers
	(@Param ("USER_ID") String chosenUser);
	
	
	
	
	












}
