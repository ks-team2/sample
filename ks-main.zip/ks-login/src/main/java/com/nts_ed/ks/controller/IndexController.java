package com.nts_ed.ks.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nts_ed.ks.dto.Employee;
import com.nts_ed.ks.param.LoginParam;
import com.nts_ed.ks.repository.EmployeeRepository;

@Controller
@RequestMapping(path = "/")
public class IndexController {

	@Autowired
	private EmployeeRepository employeeRepository;

	@PostMapping(path = "/login")
	public @ResponseBody List<Employee> login(@RequestBody LoginParam param) {
		// 社員のチェックを行います
		List<Employee> isExists = employeeRepository.checkEmployee(param.getId(), param.getPass());
		if (isExists.size() == 1) {
			System.out.println("成功");
			return isExists;
		}
		return null;
	}

	@PostMapping(path = "/testform")
	public @ResponseBody List<Employee> test(@Validated @ModelAttribute LoginParam param) {
		// 社員のチェックを行います
		return null;
	}

	@PostMapping(path = "/testform2")
	public @ResponseBody List<Employee> test2(@RequestParam("id") String id) {
		// 社員のチェックを行います
		System.out.println("test");
		System.out.println("test");
		return null;
	}

	@GetMapping(path = "/")
	public String index(Model model) {
		Employee a = new Employee();
		a.setEMPLOYEE_NAME("test");
		model.addAttribute("a", a);
		// 項目の初期化が書く必要になります。
		return "index";
	}
}
