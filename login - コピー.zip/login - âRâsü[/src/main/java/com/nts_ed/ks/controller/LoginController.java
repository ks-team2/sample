package com.nts_ed.ks.controller;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nts_ed.ks.dao.UserDao;
import com.nts_ed.ks.dao.UserService;
import com.nts_ed.ks.entity.Attendance;
import com.nts_ed.ks.entity.User;
import com.nts_ed.ks.repository.AttendanceRepository;
import com.nts_ed.ks.repository.UserRepository;



@Controller
public class LoginController {
	
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private UserService userService;

	
	//Repositoryインターフェースを自動化インスタンス
	@Autowired
	private UserRepository  t_users;
	
	@Autowired
	private AttendanceRepository  t_attendance;
	
	//EntityManager自動化インスタンス化
	@PersistenceContext
	private EntityManager entityManager;
	
	//DAO自動化インスタンス化
	@Autowired
	private UserDao userDao;//Employee_IDで検索するクラス
	
	


		
		
	/*
	 * 「/login」へアクセスした場合
	 * */	
	@GetMapping(path = "/")
	public String getLogin() {
		
		return "Login";//login.htmlに画面遷移
	}

	
	@PostMapping("/login/attendance")
	public String postAttendanceRequest(@RequestParam("Attendance")
	String USER_ID, Model model) {//,String PASSWORD
		
		
		//1件検索
		User user = userService.getUser(USER_ID);//,PASSWORD
		
		
		//検索結果をModelに登録 右employee1がID・名前・所属が代入されている
		model.addAttribute("user",user);
		
		
		//session中いつでもデータを呼び出せるようにセット
		session.setAttribute("user", user);//("data", "保存したいデータ")
		
		
		return "Attendance";//Attendance.htmlに画面遷移
	}
	
	
	


@RequestMapping("/login/attendance/month")
public ModelAndView attendanceInfo(
		@ModelAttribute Attendance attendance,
		ModelAndView mav) {
	
	
	Iterable<Attendance>attendanceinfo = t_attendance.findAll();//出勤情報検索
	
	
	//Viewにで表示する変数をModelに収納
	mav.addObject("attendanceinfo", attendanceinfo);
	
	
	//sessionの内容を呼び出す
	Object user = session.getAttribute("user"); 
	mav.addObject("user",user);//HTMLにID　名前　所属　表示できる
	
	
	
	
	
	//画面に出力するViewを指定
	mav.setViewName("AttendanceInfo");//"AttendanceInfo"html
	//ModelとView情報を返す
	return mav;
	
}
	
	
	//作成ボタンで勤怠作成
	
	@RequestMapping("/login/attendance/daywork")
	public ModelAndView attendanceRegister(@ModelAttribute Attendance attendance, ModelAndView mav) {
		
		//Viewに返す変数をModelに収納
		mav.addObject("Attendance", attendance);
		
		
		
		Object user = session.getAttribute("user"); 
		mav.addObject("user",user);//ID　名前　所属　表示できる
		
		

		
		//画面に出力するViewを指定
		mav.setViewName("AttendanceRegister");
		//ModelとView情報を返す
		return mav;
		
	}
	
	
	
	/*
	 * 「"/login/attendance/month/daywork"」へPOST送信された場合
	 * */
	@RequestMapping(value ="/login/attendance/daywork",method = RequestMethod.POST)
	//POSTデータをRegisterインスタンスとして受け入れる
	public ModelAndView attendanceRegisterPost(@ModelAttribute @Validated Attendance attendance,
			BindingResult result,ModelAndView mav) {
		
		Object user = session.getAttribute("user"); 
		mav.addObject("user",user);//ID　名前　所属　表示できる
		

		
		//入力エラーがある場合
		
		if(result.hasErrors()) {
			//エラーメッセージ
			mav.addObject("message","入力内容に誤りがあります");
			
			//画面に出力するViewを指定
			mav.setViewName("AttendanceRegister");
			
			//ModelとView情報を返す
			return mav;
		}
		
		
		//Attendance.HTMLで入力されたデータをDBに保存
		t_attendance.saveAndFlush(attendance);
				
		//リダイレクト先を指定
		mav = new ModelAndView("redirect:/login/attendance/daywork");
		//フォワードの場合もやり方は同じ（“forward:○○”）。（○○は遷移先のURL）
		
		//ModelとViewの情報を表示
		return mav;
	}
		
		



}
