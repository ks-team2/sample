package com.nts_ed.ks.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Service;


@Service
public class Calender {

	
		
//		int thisYear = Calendar.getInstance().get(Calendar.YEAR);
		int year = 2022;
		
		
		ArrayList<Integer> Months = new ArrayList<>();
		ArrayList<Integer> odddays = new ArrayList<>();
		ArrayList<Integer> febdays = new ArrayList<>();
		ArrayList<Integer> evendays = new ArrayList<>();
		ArrayList<Integer> leapdays = new ArrayList<>();{
		
		
		for (int month  = 1; month  <=12; month ++) {
			
//			System.out.println(month+"月");
			
			
			Months.add(month);
			
			
			
			if (month==1||month==3||month==5||month==6||month==8||month==10||month==12) {
					for (int oddday = 1; oddday <=31 ; oddday++) {	
//						System.out.println(oddday);
						
						odddays.add(oddday);
						
						
					}
			}if  (month == 2) {
				for (int febday = 1;  febday<=28; febday++) {
//					System.out.println(febday);
					
					febdays.add(febday);
					
					
				}
				
			}
			if(month==4||month==7||month==9||month==11){
				for (int evenday  = 1;  evenday<=30; evenday++) {
//					System.out.println(evenday);
					
					
					evendays.add(evenday);
					
					
				}
				
			}else if ((year%4==0&&month==2)) {
				for (int leapday  = 1;  leapday<=29; leapday++) {
//					System.out.println(leapday);
					
					
					leapdays.add(leapday);
					
					
					
				}
			}
		}
//	
//		String weeks= "土日月火水木金";
//		String rep =StringUtils.repeat(weeks,52);
//		System.out.println(rep);
//		System.out.println("土");
		
		

	}


		public ArrayList<Integer> getMonths() {
			// TODO 自動生成されたメソッド・スタブ
			return Months;
		}


		public ArrayList<Integer> getOdddays() {
			// TODO 自動生成されたメソッド・スタブ
			return odddays;
		}


		public ArrayList<Integer> getFebdays() {
			// TODO 自動生成されたメソッド・スタブ
			return febdays;
		}


		public ArrayList<Integer> getEvendays() {
			// TODO 自動生成されたメソッド・スタブ
			return evendays;
		}


		public ArrayList<Integer> getLeapdays() {
			// TODO 自動生成されたメソッド・スタブ
			return leapdays;
		}


}

//class Week {
//
//	public static void main(String[] args) {
//				
//		
//		int thisYear = Calendar.getInstance().get(Calendar.YEAR);
//		int year = 2023;
//		for (int month  = 1; month  <=12; month ++) {
//			System.out.println(month+"月");
//				if (month==1||month==3||month==5||month==6||month==8||month==10||month==12) {
//					for (int day = 1; day <=31 ; day++) {	
//						System.out.println(day);
//				
//				}
//			}if  (month == 2) {
//				for (int day = 1;  day<=28; day++) {
//					System.out.println(day);
//				}
//				
//			}
//			if(month==4||month==7||month==9||month==
//					11) {
//				for (int day  = 1;  day<=30; day++) {
//					System.out.println(day);
//				}
//				}else if ((year%4==0&&month==2)) {
//					for (int day  = 1;  day<=29; day++) {
//						System.out.println(day);
//				}
//				}
//				
//			}
//			String weeks= "日月火水木金土";
//			String rep =StringUtils.repeat(weeks,52);
//			System.out.println(rep);
//			System.out.println("日");
//	
//	}
//}


// class Calender2021 {
//	 
//	 public static void main(String[] args) {
//		int thisYear = Calendar.getInstance().get(Calendar.YEAR);
//		int year = 2021;
//		for (int month  = 1; month  <=12; month ++) {
//			System.out.println(month+"月");
//			if (month==1||month==3||month==5||month==6||month==8||month==10||month==12) {
//				for (int day = 1; day <=31 ; day++) {	
//					System.out.println(day);
//				}
//			}if  (month == 2) {
//				for (int day = 1;  day<=28; day++) {
//					System.out.println(day);
//				}
//			}
//			if(month==4||month==7||month==9||month==
//					11) {
//				for (int day  = 1;  day<=30; day++) {
//					System.out.println(day);
//				}
//			}else if ((year%4==0&&month==2)) {
//				for (int day  = 1;  day<=29; day++) {
//					System.out.println(day);
//				}
//			}
//			
//				String weeks= "金土日月火水木";
//				String rep =StringUtils.repeat(weeks,52);
//				System.out.println(rep);
//				System.out.println("金");
//		}
//	}
//}


