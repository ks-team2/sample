package com.nts_ed.ks.dao;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;






@Repository
public class EmployeeDao {


	/*
	 * 社員検索
	 * @param String EMPLOYEE_ID
	 * @param String PASSWORD
	 * @return ArrayList<Employee>employee_list
	 * */
	
	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Map<String, Object> findBy(String EMPLOYEE_ID){//,String PASSWORD
		
		//SELECT句設定
		String query="SELECT*"
				+ " FROM t_employee"
				+ " WHERE EMPLOYEE_ID=? ";//AND PASSWORD=?
				
		//検索実行
		
		Map<String, Object>employee=jdbcTemplate.queryForMap(query,EMPLOYEE_ID);//, PASSWORD
		
		//クエリ実行
		return employee;
	}
	
}
