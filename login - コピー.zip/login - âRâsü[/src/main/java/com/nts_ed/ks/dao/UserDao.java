package com.nts_ed.ks.dao;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;






@Repository//DBにコネクトする@SpringBoot
public class UserDao {


	/*
	 * 社員検索
	 * @param String EMPLOYEE_ID
	 * @param String PASSWORD
	 * @return ArrayList<Employee>employee_list
	 * */
	@Autowired//SpringBootでないDB検索
	private JdbcTemplate jdbcTemplate;
	
	
	
	
	
	
	public Map<String, Object> findBy(String USER_ID){//,String PASSWORD
		
		//SELECT句設定
		String query="SELECT*"
				+ " FROM t_users"
				+ " WHERE USER_ID=? ";//AND PASSWORD=?
				
		//検索実行
		
		Map<String, Object>user=jdbcTemplate.queryForMap(query,USER_ID);//, PASSWORD
		
		//クエリ実行
		return user;
	}
	
}
