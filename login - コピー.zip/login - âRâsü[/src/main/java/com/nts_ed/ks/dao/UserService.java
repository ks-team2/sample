package com.nts_ed.ks.dao;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nts_ed.ks.entity.User;



@Service//@Serviceはロジック処理を行うクラス
public class UserService {

	
	@Autowired
	private UserDao userDao;
	
	//社員を1人取得する

	public User getUser(String USER_ID){//,String PASSWORD
		//検索
		
		Map<String, Object> map = userDao.findBy(USER_ID);//,PASSWORD
		
		//MAPから値を取得
		
		USER_ID=(String)map.get("USER_ID");
		//PASSWORD = (String)map.get("PASSWORD");
		
		String USER_NAME =(String)map.get("USER_NAME");
		String DEPT_ID =(String)map.get("DEPT_ID");
		
		
		
		//Employeeクラスに値をセット
		User user = new User();
		
		user.setUSER_ID(USER_ID);
		//employee.setPASSWORD(PASSWORD);
		
		user.setUSER_NAME(USER_NAME);
		user.setDEPT_ID(DEPT_ID);
		
		return user;
		
	}
	

	
	
	
	
}
