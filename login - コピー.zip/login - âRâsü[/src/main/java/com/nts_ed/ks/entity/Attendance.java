package com.nts_ed.ks.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;


//勤怠登録するファイル

@Data//lombokでgetter/setterが自動化
@Entity//DBに自動登録される
@Table(name = "t_attendance")//DBに登録するテーブル名を指定

@Embeddable
public class Attendance implements Serializable {
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	
//	private String ATTENDANCE_ID;
	
	@Column(length =10)
	private String ATTENDANCE_DATE;
	private String START_TIME;
	private String END_TIME;
	private String REST_HOURS;
	private String WORKING_HOURS;//
	private String OVERTIME_HOURS;//
	private String ABSENCE_HOURS;
	private String STATUS_ID;
	
	private String REMARKS;
	
	private String DEL_FLG;
	private String COMMENT;//管理者の備考
	private Date   CREATE_DATE;
	private String CREATE_USER;
	private Date   UPDATE_DATE;
	private String UPDATE_USER;
	
	@ManyToOne(fetch = FetchType.LAZY )//, cascade =  CascadeType.ALL
	@JoinColumn(name = "user_id",referencedColumnName = "USER_ID")//データベース上のカラム名として反映
	private User user;


	
	
	
	
}
