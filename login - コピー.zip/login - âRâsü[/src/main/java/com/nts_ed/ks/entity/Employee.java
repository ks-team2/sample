package com.nts_ed.ks.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "t_employee")
public class Employee implements Serializable {
	
	
	
	@Id
	//これが初期登録されるテーブル
//	@NotBlank(message = "社員IDは存在しません。再度入力し直してください")
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String EMPLOYEE_ID;
	
	private String EMPLOYEE_NAME;
	
//	@NotBlank(message = "パスワードが間違っています。再度入力しなおしてください。")
	private String PASSWORD;
	
	
	
	private String GENDER;
	
	private String AGE;
	
	private String DEPT_ID;
	
	private String JOINING;
	
	private String MAIL_ADDRESS;
	
	private String DEL_FLG;
	private String CREATE_USER;
	private Date CREATE_DATE;
	private Date UPDATE_DATE;
	private String UPDATE_USER;
	
	@OneToMany(mappedBy = "employee")//Message から参照する際に使用されます,cascade = CascadeType.ALL
	private List<Attendance> attendanceList;

	
	
}
