package com.nts_ed.ks.controller;


import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nts_ed.ks.dao.UserDao;
import com.nts_ed.ks.entity.User;
import com.nts_ed.ks.repository.UserRepository;



@Controller
public class AdministerController {

	
	//Repositoryインターフェースを自動化インスタンス
	@Autowired
	private UserRepository  t_users;
	
	//EntityManager自動化インスタンス化
	@PersistenceContext
	private EntityManager entityManager;
	
	//DAO自動化インスタンス化
	@Autowired
	private UserDao userDao;
	
	@PostConstruct
	public void init() {
		userDao = new UserDao(entityManager);
	}
	
	
	/*
	 * 「/Administer」へアクセスがあった場合
	 * 
	 * */
	
	@RequestMapping("/administer")
	public ModelAndView list(ModelAndView mav) {
		//t_employeeテーブルから全件取得
		Iterable<User> user_list = t_users.findAll();
		
		//Viewに渡す変数をModelに格納
		mav.addObject("user_list",user_list);
		
		//画面に出力するViewを指定
		mav.setViewName("Administer");
		
		//ModelとView情報を返す
		return mav;
	}
	
	/*
	 * 「/search」へアクセスがあった場合
	 * */
	@RequestMapping("/search")
	public ModelAndView search(HttpServletRequest request,ModelAndView mav) {
		//T_EMPLOYEEテーブルから検索
		Iterable<User> user_list = userDao.find(
				request.getParameter("EMPLOYEE_ID"),
				request.getParameter("DEPT_ID"),
				request.getParameter("JOINING")
				
		);
		
		//Viewに渡す変数をModelに格納
		mav.addObject("user_list", user_list);
		
		//画面に出力するViewを指定
		mav.setViewName("Administer");
		
		//ModelとView情報を返す
		return mav;
		
	}
	
}
