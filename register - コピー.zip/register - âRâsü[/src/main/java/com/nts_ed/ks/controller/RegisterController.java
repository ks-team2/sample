package com.nts_ed.ks.controller;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nts_ed.ks.dao.Register;
import com.nts_ed.ks.dao.UserDao;
import com.nts_ed.ks.repository.UserRepository;


@Controller
public class RegisterController {

	
	//Repositoryインターフェースを自動化インスタンス
		@Autowired
		private UserRepository  t_users;
		
		//EntityManager自動化インスタンス化
		@PersistenceContext
		private EntityManager entityManager;
		
		//DAO自動化インスタンス化
		@Autowired
		private UserDao userDao;
		
		@PostConstruct
		public void init() {
			userDao = new UserDao(entityManager);
		}
		

	@RequestMapping("/insert")
	public ModelAndView insert(@ModelAttribute Register register , ModelAndView mav) {
		
		//Viewに返す変数をModelに収納
		mav.addObject("Register", register);
		
		//画面に出力するViewを指定
		mav.setViewName("Register");
		//ModelとView情報を返す
		return mav;
		
	}
	
	
	
	/*
	 * 「/insert」へPOST送信された場合
	 * */
	@RequestMapping(value ="/insert",method = RequestMethod.POST)
	//POSTデータをRegisterインスタンスとして受け入れる
	public ModelAndView insertPost(@ModelAttribute @Validated Register register,
			BindingResult result,ModelAndView mav) {
		//入力エラーがある場合
		if(result.hasErrors()) {
			//エラーメッセージ
			mav.addObject("message","入力内容に誤りがあります");
			
			//画面に出力するViewを指定
			mav.setViewName("Register");
			
			//ModelとView情報を返す
			return mav;
		}
		
		
		//入力されたデータをDBに保存
		t_users.saveAndFlush(register);
				
		//リダイレクト先を指定
		mav = new ModelAndView("redirect:/insert");
		//フォワードの場合もやり方は同じです（“forward:○○”）。○○は遷移先のURL
		//ModelとView情報を返す
		return mav;
	}
		

	
}
