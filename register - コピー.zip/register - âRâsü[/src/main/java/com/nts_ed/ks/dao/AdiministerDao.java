package com.nts_ed.ks.dao;

import lombok.Data;

@Data
public class AdiministerDao {
	
	private String EMPLOYEE_ID;
	
	private String DEPT_ID;
	
	private String joiningFrom;
	private String joiningTo;
	
	public AdiministerDao() {
		
		EMPLOYEE_ID="";
		DEPT_ID="";
		joiningFrom="";
		joiningTo="";
	}

}
