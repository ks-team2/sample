package com.nts_ed.ks.dao;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.Data;


@Data
@Entity
@Table(name = "t_users")
public class Register {

	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@NotBlank(message = "社員IDは必要です。")
	private String USER_ID;
	
	@NotBlank(message = "入社年月日は必要です。")
	private String JOINING;
	
	@Column(length =20)
	@NotBlank(message = "氏名は必要です。")
	private String USER_NAME;
	
	@Column(length =20)
	@NotBlank(message = "パスワードは必要です。")
	private String PASSWORD;
	
	@Column(length =3)
	@NotBlank(message = "性別は必要です。")
	private String GENDER;
	
	@Column(length =3)
	@NotBlank(message = "年齢は必要です。")
	private String AGE;
	
	@Column(length =10)
	@NotBlank(message = "所属IDは必要です。")
	private String DEPT_ID;
	
	@Column(length =50)
	@NotBlank(message = "メールアドレスは必要です。")
	private String MAIL_ADDRESS;
	
	private String DEL_FLG;
	private String CREATE_USER;
	private Date CREATE_DATE;
	private Date UPDATE_DATE;
	private String UPDATE_USER;

}
