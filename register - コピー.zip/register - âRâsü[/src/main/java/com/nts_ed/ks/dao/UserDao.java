package com.nts_ed.ks.dao;


import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.nts_ed.ks.entity.User;




@Repository
public class UserDao {

	//エンティティマネージャー
	private EntityManager entityManager;
	
	//クエリ生成用インスタンス
	private CriteriaBuilder builder;
	
	//クエリ実行用インスタンス
	private CriteriaQuery<User> query;
	
	//検索されるエンティティのルート
	private Root<User> root;
	
	/*
	 * コンストラクタ（DB接続準備）
	 * */
	public UserDao(EntityManager entityManager) {
		//EntityManager取得
		this.entityManager = entityManager;
		//クエリ生成用インスタンス
		builder = entityManager.getCriteriaBuilder();
		//クエリ実行用インスタンス
		query = builder.createQuery(User.class);
		//検索されるエンティティのルート
		root = query.from(User.class);
	}
	/*
	 * 社員検索
	 * @param String EMPLOYEE_ID
	 * @param String DEPT_ID
	 * @param String JOINING
	 * @return ArrayList<Employee>employee_list
	 * */
	
	public ArrayList<User> find(String EMPLOYEE_ID,String DEPT_ID,String JOINING){
		//SELECT句設定
		query.select(root);
		//WHERE句設定
		query.where(
				builder.like(root.get("EMPLOYEE_ID"),"%" +  EMPLOYEE_ID + "%" ),
				builder.like(root.get("DEPT_ID"), "%" + DEPT_ID + "%" ),
				builder.like(root.get("JOINING"), "%" + JOINING + "%")
				
		);
		//クエリ実行
		return(ArrayList<User>)entityManager.createQuery(query).getResultList();
		}
		
	}
